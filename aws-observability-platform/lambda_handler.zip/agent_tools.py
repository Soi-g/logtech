"""
Bedrock Agent Action Group - 옵저버빌리티 도구 실행
Agent가 호출하는 도구 함수들
"""

import json
import os
import boto3

# 환경변수 추가
os.environ.setdefault('AMP_ENDPOINT', '')
os.environ.setdefault('OPENSEARCH_ENDPOINT', '')
os.environ.setdefault('OPENSEARCH_USER', 'admin')
os.environ.setdefault('OPENSEARCH_PASSWORD', '')
os.environ.setdefault('AWS_REGION_NAME', 'ap-northeast-2')

from agents_aws import (
    get_metrics_summary,
    get_error_logs,
    get_slow_spans
)

dynamodb = boto3.resource('dynamodb', region_name='ap-northeast-2')
MEMORY_TABLE = os.environ.get('INCIDENT_MEMORY_TABLE', 'log-platform-dev-incident-memory')


class IncidentMemory:
    """과거 장애 이력"""
    
    def __init__(self):
        self.table = dynamodb.Table(MEMORY_TABLE)
    
    def search_similar_incidents(self, alert_name: str, limit: int = 5) -> list:
        try:
            response = self.table.query(
                IndexName='alert_name-timestamp-index',
                KeyConditionExpression='alert_name = :alert_name',
                ExpressionAttributeValues={':alert_name': alert_name},
                ScanIndexForward=False,
                Limit=limit
            )
            return response.get('Items', [])
        except Exception as e:
            print(f"메모리 검색 실패: {e}")
            return []
    
    def get_incident_stats(self, alert_name: str) -> dict:
        incidents = self.search_similar_incidents(alert_name, limit=100)
        
        if not incidents:
            return {'count': 0}
        
        total_time = sum(i.get('resolution_time_minutes', 0) for i in incidents)
        
        from collections import Counter
        causes = [i.get('root_cause') for i in incidents if i.get('root_cause')]
        most_common = Counter(causes).most_common(1)[0][0] if causes else "Unknown"
        
        return {
            'count': len(incidents),
            'avg_resolution_time': total_time / len(incidents) if incidents else 0,
            'most_common_root_cause': most_common,
            'last_occurrence': incidents[0]['timestamp']
        }


def lambda_handler(event, context):
    """
    Bedrock Agent Action Group Lambda Handler
    
    Event 구조:
    {
        "actionGroup": "observability-tools",
        "apiPath": "/metrics/summary",
        "httpMethod": "GET",
        "parameters": [...]
    }
    """
    
    print(f"Agent Tools 호출: {json.dumps(event)}")
    
    action_group = event.get('actionGroup')
    api_path = event.get('apiPath')
    http_method = event.get('httpMethod')
    parameters = event.get('parameters', [])
    
    # 파라미터를 dict로 변환
    params = {p['name']: p['value'] for p in parameters}
    
    try:
        # 라우팅
        if api_path == '/metrics/summary':
            result = handle_metrics_summary(params)
        
        elif api_path == '/logs/errors':
            result = handle_error_logs(params)
        
        elif api_path == '/traces/slow':
            result = handle_slow_traces(params)
        
        elif api_path == '/memory/similar-incidents':
            result = handle_similar_incidents(params)
        
        else:
            result = {'error': f'Unknown API path: {api_path}'}
        
        # Bedrock Agent 응답 형식
        return {
            'messageVersion': '1.0',
            'response': {
                'actionGroup': action_group,
                'apiPath': api_path,
                'httpMethod': http_method,
                'httpStatusCode': 200,
                'responseBody': {
                    'application/json': {
                        'body': json.dumps(result, ensure_ascii=False)
                    }
                }
            }
        }
    
    except Exception as e:
        print(f"❌ 도구 실행 오류: {e}")
        return {
            'messageVersion': '1.0',
            'response': {
                'actionGroup': action_group,
                'apiPath': api_path,
                'httpMethod': http_method,
                'httpStatusCode': 500,
                'responseBody': {
                    'application/json': {
                        'body': json.dumps({'error': str(e)})
                    }
                }
            }
        }


def handle_metrics_summary(params):
    """메트릭 요약 조회"""
    time_range = int(params.get('time_range_minutes', 60))
    
    summary = get_metrics_summary(time_range_minutes=time_range)
    
    return {
        'time_range_minutes': time_range,
        'metrics': summary
    }


def handle_error_logs(params):
    """에러 로그 조회"""
    limit = int(params.get('limit', 10))
    
    errors = get_error_logs(limit=limit)
    
    return {
        'error_count': len(errors),
        'errors': errors[:limit]
    }


def handle_slow_traces(params):
    """느린 트레이스 조회"""
    traces = get_slow_spans(threshold_ms=1000, limit=10)
    
    return {
        'slow_trace_count': len(traces),
        'traces': traces
    }


def handle_similar_incidents(params):
    """과거 유사 장애 검색"""
    alert_name = params.get('alert_name')
    
    if not alert_name:
        return {'error': 'alert_name parameter required'}
    
    memory = IncidentMemory()
    incidents = memory.search_similar_incidents(alert_name, limit=5)
    stats = memory.get_incident_stats(alert_name)
    
    return {
        'alert_name': alert_name,
        'similar_incidents_count': len(incidents),
        'statistics': stats,
        'recent_incidents': [
            {
                'timestamp': i['timestamp'],
                'root_cause': i.get('root_cause'),
                'resolution': i.get('resolution'),
                'resolution_time_minutes': i.get('resolution_time_minutes')
            }
            for i in incidents
        ]
    }
