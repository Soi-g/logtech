"""
AWS Observability Platform - Graph Agent with Memory
기존 LangGraph 구조 유지 + DynamoDB 장기 메모리 추가
"""

import os
import json
from typing import TypedDict, Annotated
from datetime import datetime

from langgraph.graph import StateGraph, END
from langchain_aws import ChatBedrockConverse

from agents_aws import (
    get_metrics_summary, get_jvm_metrics, get_http_metrics,
    get_logs_summary, search_logs, get_error_logs,
    get_traces_summary, get_slow_spans, get_trace_by_id,
    metrics_agent, logs_agent, traces_agent
)
from runbooks_aws import search_runbook

# DynamoDB 메모리 추가
import boto3
dynamodb = boto3.resource('dynamodb', region_name='ap-northeast-2')
MEMORY_TABLE = os.environ.get('INCIDENT_MEMORY_TABLE', 'log-platform-dev-incident-memory')


# ============================================================
# 장기 메모리 (DynamoDB)
# ============================================================
class IncidentMemory:
    """과거 장애 이력 저장 및 검색"""
    
    def __init__(self):
        self.table = dynamodb.Table(MEMORY_TABLE)
    
    def search_similar_incidents(self, alert_name: str, limit: int = 3) -> list:
        """유사 장애 이력 검색"""
        try:
            response = self.table.query(
                IndexName='alert_name-timestamp-index',
                KeyConditionExpression='alert_name = :alert_name',
                ExpressionAttributeValues={':alert_name': alert_name},
                ScanIndexForward=False,
                Limit=limit
            )
            return response.get('Items', [])
        except Exception as e:
            print(f"⚠️ 메모리 검색 실패: {e}")
            return []
    
    def get_stats(self, alert_name: str) -> dict:
        """알람 통계"""
        incidents = self.search_similar_incidents(alert_name, limit=100)
        
        if not incidents:
            return {'count': 0, 'is_new': True}
        
        total_time = sum(i.get('resolution_time_minutes', 0) for i in incidents)
        
        # 가장 흔한 원인
        from collections import Counter
        causes = [i.get('root_cause') for i in incidents if i.get('root_cause')]
        most_common_cause = Counter(causes).most_common(1)[0][0] if causes else "Unknown"
        
        return {
            'count': len(incidents),
            'is_new': False,
            'avg_resolution_time': total_time / len(incidents) if incidents else 0,
            'most_common_cause': most_common_cause,
            'last_occurrence': incidents[0]['timestamp']
        }
    
    def save_incident(self, incident_data: dict):
        """장애 해결 후 저장"""
        incident_id = f"{incident_data['alert_name']}_{datetime.utcnow().isoformat()}"
        
        item = {
            'incident_id': incident_id,
            'alert_name': incident_data['alert_name'],
            'timestamp': datetime.utcnow().isoformat(),
            'root_cause': incident_data.get('root_cause'),
            'resolution': incident_data.get('resolution'),
            'resolution_time_minutes': incident_data.get('resolution_time', 0),
            'severity': incident_data.get('severity', 'medium'),
            'metrics_snapshot': json.dumps(incident_data.get('metrics', {})),
        }
        
        self.table.put_item(Item=item)
        print(f"✅ 장애 이력 저장: {incident_id}")


# ============================================================
# State 정의 (메모리 필드 추가)
# ============================================================
def merge_str(existing: str, new: str) -> str:
    return new if new else existing

class ObservabilityState(TypedDict):
    question:        Annotated[str, lambda x, y: y]
    alert_name:      Annotated[str, lambda x, y: y]
    severity:        Annotated[str, lambda x, y: y]
    amp_link:        Annotated[str, lambda x, y: y]
    category:        Annotated[list[str], lambda x, y: y]
    
    # 메모리 관련 필드 추가
    memory_stats:    Annotated[dict, lambda x, y: y]
    similar_incidents: Annotated[list, lambda x, y: y]
    
    metrics_result:  Annotated[str, merge_str]
    logs_result:     Annotated[str, merge_str]
    traces_result:   Annotated[str, merge_str]
    runbook_result:  Annotated[str, merge_str]
    final_answer:    Annotated[str, lambda x, y: y]


llm = ChatBedrockConverse(
    model="apac.anthropic.claude-sonnet-4-20250514-v1:0",
    region_name="ap-northeast-2",
)


# ============================================================
# 노드 정의 (메모리 노드 추가)
# ============================================================

def memory_node(state: ObservabilityState) -> ObservabilityState:
    """
    🆕 과거 장애 이력 조회 (첫 번째 노드)
    """
    alert_name = state.get("alert_name", "")
    
    if not alert_name:
        return {
            **state,
            "memory_stats": {'count': 0, 'is_new': True},
            "similar_incidents": []
        }
    
    print(f"🧠 메모리 검색: {alert_name}")
    memory = IncidentMemory()
    
    stats = memory.get_stats(alert_name)
    similar = memory.search_similar_incidents(alert_name, limit=3)
    
    if stats['is_new']:
        print(f"   ⚠️ 신규 장애 패턴 (과거 이력 없음)")
    else:
        print(f"   ✅ 과거 {stats['count']}회 발생")
        print(f"   📊 평균 해결 시간: {stats['avg_resolution_time']:.1f}분")
        print(f"   🔍 가장 흔한 원인: {stats['most_common_cause']}")
    
    return {
        **state,
        "memory_stats": stats,
        "similar_incidents": similar
    }


def classify_node(state: ObservabilityState) -> ObservabilityState:
    """질문 분류 (메모리 정보 활용)"""
    question = state["question"]
    stats = state.get("memory_stats", {})
    
    # 과거 이력이 있으면 빠른 분류
    if not stats.get('is_new'):
        print(f"📋 과거 이력 기반 빠른 분류")
        # 과거 패턴 기반으로 필요한 데이터 결정
        categories = ["metrics", "logs", "traces"]
    else:
        # 신규 패턴은 LLM으로 분류
        prompt = f"""다음 질문을 분석해서 어떤 데이터가 필요한지 판단하세요.

질문: {question}

반드시 아래 카테고리 중 해당하는 것만 골라서 쉼표로 구분해서 답하세요.

카테고리:
- metrics: JVM, CPU, 메모리, HTTP 응답시간 관련
- logs: 로그, 에러, WARN, INFO 관련
- traces: 트레이스, 느린 요청, 응답시간 관련
- all: 전체 점검

답변 (카테고리만):"""

        response = llm.invoke(prompt)
        categories_str = response.content.strip().lower()

        if "all" in categories_str:
            categories = ["metrics", "logs", "traces"]
        else:
            categories = [c.strip() for c in categories_str.split(",") 
                         if c.strip() in ["metrics", "logs", "traces"]]

        if not categories:
            categories = ["metrics", "logs", "traces"]

    print(f"📋 분류 결과: {categories}")
    return {**state, "category": categories}


def metrics_node(state: ObservabilityState) -> ObservabilityState:
    if "metrics" not in state.get("category", []):
        return {**state, "metrics_result": ""}

    print("📊 Metrics Agent 실행 중...")
    result = metrics_agent(state["question"])
    return {**state, "metrics_result": str(result)}


def logs_node(state: ObservabilityState) -> ObservabilityState:
    if "logs" not in state.get("category", []):
        return {**state, "logs_result": ""}

    print("📝 Logs Agent 실행 중...")
    result = logs_agent(state["question"])
    return {**state, "logs_result": str(result)}


def traces_node(state: ObservabilityState) -> ObservabilityState:
    if "traces" not in state.get("category", []):
        return {**state, "traces_result": ""}

    print("🔍 Traces Agent 실행 중...")
    result = traces_agent(state["question"])
    return {**state, "traces_result": str(result)}


def runbook_node(state: ObservabilityState) -> ObservabilityState:
    print("📖 런북 검색 중...")
    try:
        query = f"{state.get('alert_name', '')} {state['question']}"
        runbooks = search_runbook(query, n_results=2)

        if not runbooks:
            return {**state, "runbook_result": "관련 런북 없음"}

        lines = []
        for rb in runbooks:
            lines.append(f"[{rb['source']}] (관련도: {rb['relevance']:.2f})")
            lines.append(f"  섹션: {rb['section']}")
            if rb.get("content"):
                lines.append(f"  내용: {rb['content'][:300]}")

        result = "\n".join(lines)
        return {**state, "runbook_result": result}

    except Exception as e:
        print(f"런북 검색 오류: {e}")
        return {**state, "runbook_result": f"런북 검색 실패: {e}"}


def synthesize_node(state: ObservabilityState) -> ObservabilityState:
    """
    결과 종합 (메모리 정보 포함)
    """
    print("🧩 결과 종합 중...")
    
    parts = []
    
    # 🆕 과거 이력 추가
    stats = state.get("memory_stats", {})
    similar = state.get("similar_incidents", [])
    
    if not stats.get('is_new'):
        memory_info = f"""[과거 장애 이력]
총 발생 횟수: {stats['count']}회
평균 해결 시간: {stats['avg_resolution_time']:.1f}분
가장 흔한 원인: {stats['most_common_cause']}

최근 3건:"""
        for idx, incident in enumerate(similar[:3], 1):
            memory_info += f"""
{idx}. {incident['timestamp']}
   원인: {incident.get('root_cause', 'Unknown')}
   해결: {incident.get('resolution', 'Unknown')}
   소요: {incident.get('resolution_time_minutes', 0)}분"""
        
        parts.append(memory_info)
        print(f"✅ 과거 이력 {len(similar)}건 포함")
    else:
        parts.append("[과거 장애 이력]\n⚠️ 신규 장애 패턴 (과거 이력 없음)")
        print(f"⚠️ 신규 장애 패턴")
    
    # 현재 분석 결과
    if state.get("metrics_result"):
        parts.append(f"[메트릭 분석]\n{state['metrics_result']}")
    if state.get("logs_result"):
        parts.append(f"[로그 분석]\n{state['logs_result']}")
    if state.get("traces_result"):
        parts.append(f"[트레이스 분석]\n{state['traces_result']}")
    
    runbook_result = state.get("runbook_result", "")
    if runbook_result and runbook_result != "관련 런북 없음":
        parts.append(f"[런북 참조]\n{runbook_result}")

    combined = "\n\n".join(parts)
    alert_name = state.get("alert_name", "Unknown")
    severity = state.get("severity", "critical")

    prompt = f"""당신은 AWS 옵저버빌리티 플랫폼의 인시던트 분석 AI입니다.

알람명: {alert_name}
심각도: {severity}
질문: {state['question']}

분석 데이터:
{combined}

**중요**: 위 데이터에 [과거 장애 이력]이 있으면 반드시 참조하세요.
- 과거 이력이 있으면 그때의 원인과 해결 방법을 우선 고려
- 신규 패턴이면 명시적으로 언급

아래 JSON 형식으로만 답변하세요:

{{
  "incident_summary": "한 문장 요약",
  "is_recurring": {not stats.get('is_new')},
  "past_occurrences": {stats.get('count', 0)},
  "likely_root_causes": ["원인1", "원인2"],
  "severity": "{severity}",
  "impact": "영향 범위",
  "immediate_actions": ["즉시 조치1", "즉시 조치2"],
  "follow_up_actions": ["후속 조치1"],
  "evidence_summary": ["근거1", "근거2"],
  "runbook_references": [
    {{
      "source": "파일명.md",
      "section": "섹션",
      "relevance": "관련성"
    }}
  ]
}}"""

    response = llm.invoke(prompt)
    raw = response.content.strip()

    try:
        parsed = json.loads(raw)
        final = json.dumps(parsed, ensure_ascii=False)
    except json.JSONDecodeError:
        fallback = {
            "incident_summary": f"{alert_name} 알람 발생",
            "is_recurring": not stats.get('is_new'),
            "past_occurrences": stats.get('count', 0),
            "likely_root_causes": [stats.get('most_common_cause', '분석 필요')],
            "severity": severity,
            "impact": "영향 범위 파악 중",
            "immediate_actions": ["시스템 로그 확인"],
            "follow_up_actions": ["근본 원인 분석"],
            "evidence_summary": [],
            "runbook_references": []
        }
        final = json.dumps(fallback, ensure_ascii=False)

    return {**state, "final_answer": final}


# ============================================================
# Graph 구성 (메모리 노드 추가)
# ============================================================
def build_graph():
    graph = StateGraph(ObservabilityState)

    # 🆕 memory 노드 추가 (첫 번째)
    graph.add_node("memory", memory_node)
    graph.add_node("classify", classify_node)
    graph.add_node("metrics", metrics_node)
    graph.add_node("logs", logs_node)
    graph.add_node("traces", traces_node)
    graph.add_node("runbook", runbook_node)
    graph.add_node("synthesize", synthesize_node)

    # 🆕 흐름 변경: memory → classify → ...
    graph.set_entry_point("memory")
    graph.add_edge("memory", "classify")
    graph.add_edge("classify", "metrics")
    graph.add_edge("classify", "logs")
    graph.add_edge("classify", "traces")
    graph.add_edge("classify", "runbook")
    graph.add_edge("metrics", "synthesize")
    graph.add_edge("logs", "synthesize")
    graph.add_edge("traces", "synthesize")
    graph.add_edge("runbook", "synthesize")
    graph.add_edge("synthesize", END)

    return graph.compile()


# ============================================================
# 장애 해결 후 메모리 저장 함수
# ============================================================
def save_resolution(alert_name: str, report: dict, resolution_time_minutes: int):
    """
    장애 해결 후 호출 (Slack에서 "해결 완료" 버튼 클릭 시)
    """
    memory = IncidentMemory()
    
    incident_data = {
        'alert_name': alert_name,
        'root_cause': report.get('likely_root_causes', ['Unknown'])[0],
        'resolution': ', '.join(report.get('immediate_actions', [])),
        'resolution_time': resolution_time_minutes,
        'severity': report.get('severity', 'medium'),
        'metrics': {}
    }
    
    memory.save_incident(incident_data)
    print(f"✅ 장애 해결 이력 저장 완료")


if __name__ == "__main__":
    print("=" * 60)
    print("🔍 AWS Observability Platform - Graph Agent with Memory")
    print("=" * 60)

    app = build_graph()

    result = app.invoke({
        "question": "JVM 메모리가 높습니다",
        "alert_name": "HighJvmMemory",
        "severity": "high",
        "amp_link": "",
        "category": [],
        "memory_stats": {},
        "similar_incidents": [],
        "metrics_result": "",
        "logs_result": "",
        "traces_result": "",
        "runbook_result": "",
        "final_answer": "",
    })

    report = json.loads(result["final_answer"])
    print(f"\n🤖 요약: {report.get('incident_summary')}")
    print(f"   재발 여부: {'✅ 과거 {0}회 발생'.format(report.get('past_occurrences')) if report.get('is_recurring') else '⚠️ 신규 패턴'}")
    print(f"   즉시 조치: {report.get('immediate_actions')}\n")
