"""
AWS Bedrock Agent Runtime + Memory 기반 장애 분석
과거 장애 이력을 학습하여 재발 시 빠른 대응
"""

import os
import json
import boto3
from datetime import datetime
from typing import Dict, List, Optional

# ============================================================
# 클라이언트 초기화
# ============================================================
bedrock_agent_runtime = boto3.client('bedrock-agent-runtime', region_name='ap-northeast-2')
dynamodb = boto3.resource('dynamodb', region_name='ap-northeast-2')

AGENT_ID = os.environ.get('BEDROCK_AGENT_ID')
AGENT_ALIAS_ID = os.environ.get('BEDROCK_AGENT_ALIAS_ID')
MEMORY_TABLE = os.environ.get('INCIDENT_MEMORY_TABLE', 'observability-incident-memory')


# ============================================================
# 장기 메모리 (DynamoDB)
# ============================================================
class IncidentMemory:
    """과거 장애 이력 저장 및 검색"""
    
    def __init__(self):
        self.table = dynamodb.Table(MEMORY_TABLE)
    
    def save_incident(self, incident_data: Dict):
        """장애 이력 저장"""
        incident_id = f"{incident_data['alert_name']}_{datetime.utcnow().isoformat()}"
        
        item = {
            'incident_id': incident_id,
            'alert_name': incident_data['alert_name'],
            'timestamp': datetime.utcnow().isoformat(),
            'root_cause': incident_data.get('root_cause'),
            'resolution': incident_data.get('resolution'),
            'metrics_snapshot': incident_data.get('metrics'),
            'logs_pattern': incident_data.get('logs_pattern'),
            'resolution_time_minutes': incident_data.get('resolution_time'),
            'severity': incident_data.get('severity'),
            'tags': incident_data.get('tags', []),
        }
        
        self.table.put_item(Item=item)
        print(f"✅ 장애 이력 저장: {incident_id}")
        return incident_id
    
    def search_similar_incidents(self, alert_name: str, limit: int = 5) -> List[Dict]:
        """유사 장애 이력 검색"""
        try:
            response = self.table.query(
                IndexName='alert_name-timestamp-index',
                KeyConditionExpression='alert_name = :alert_name',
                ExpressionAttributeValues={':alert_name': alert_name},
                ScanIndexForward=False,  # 최신순
                Limit=limit
            )
            return response.get('Items', [])
        except Exception as e:
            print(f"⚠️ 유사 장애 검색 실패: {e}")
            return []
    
    def get_incident_stats(self, alert_name: str) -> Dict:
        """특정 알람의 통계"""
        incidents = self.search_similar_incidents(alert_name, limit=100)
        
        if not incidents:
            return {'count': 0}
        
        total_resolution_time = sum(
            i.get('resolution_time_minutes', 0) for i in incidents
        )
        
        return {
            'count': len(incidents),
            'avg_resolution_time': total_resolution_time / len(incidents),
            'most_common_root_cause': self._get_most_common(incidents, 'root_cause'),
            'last_occurrence': incidents[0]['timestamp'],
        }
    
    def _get_most_common(self, incidents: List[Dict], field: str) -> str:
        """가장 빈번한 값 찾기"""
        from collections import Counter
        values = [i.get(field) for i in incidents if i.get(field)]
        if not values:
            return "Unknown"
        return Counter(values).most_common(1)[0][0]


# ============================================================
# Bedrock Agent Runtime 호출
# ============================================================
def invoke_agent_with_memory(
    alert_name: str,
    question: str,
    session_id: Optional[str] = None,
    enable_memory: bool = True
) -> Dict:
    """
    Bedrock Agent 호출 (메모리 활성화)
    
    Args:
        alert_name: 알람명
        question: 분석 요청
        session_id: 세션 ID (없으면 자동 생성)
        enable_memory: 메모리 사용 여부
    """
    
    if not session_id:
        session_id = f"incident-{alert_name}-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}"
    
    # 1. 과거 장애 이력 조회
    memory = IncidentMemory()
    similar_incidents = memory.search_similar_incidents(alert_name, limit=3)
    stats = memory.get_incident_stats(alert_name)
    
    # 2. 컨텍스트 구성
    context = f"""
알람명: {alert_name}
질문: {question}

과거 장애 이력:
- 총 발생 횟수: {stats.get('count', 0)}회
- 평균 해결 시간: {stats.get('avg_resolution_time', 0):.1f}분
- 가장 흔한 원인: {stats.get('most_common_root_cause', 'Unknown')}
"""
    
    if similar_incidents:
        context += "\n최근 3건의 유사 장애:\n"
        for idx, incident in enumerate(similar_incidents[:3], 1):
            context += f"""
{idx}. {incident['timestamp']}
   원인: {incident.get('root_cause', 'Unknown')}
   해결: {incident.get('resolution', 'Unknown')}
   소요시간: {incident.get('resolution_time_minutes', 0)}분
"""
    
    # 3. Agent 호출
    try:
        response = bedrock_agent_runtime.invoke_agent(
            agentId=AGENT_ID,
            agentAliasId=AGENT_ALIAS_ID,
            sessionId=session_id,
            enableTrace=True,
            inputText=context
        )
        
        # 4. 응답 스트림 처리
        result = ""
        for event in response['completion']:
            if 'chunk' in event:
                chunk = event['chunk']
                if 'bytes' in chunk:
                    result += chunk['bytes'].decode('utf-8')
        
        return {
            'session_id': session_id,
            'response': result,
            'similar_incidents_count': len(similar_incidents),
            'has_history': len(similar_incidents) > 0
        }
        
    except Exception as e:
        print(f"❌ Agent 호출 실패: {e}")
        return {
            'session_id': session_id,
            'response': f"Agent 호출 실패: {e}",
            'error': str(e)
        }


# ============================================================
# 장애 해결 후 메모리 업데이트
# ============================================================
def save_incident_resolution(
    alert_name: str,
    root_cause: str,
    resolution: str,
    resolution_time_minutes: int,
    metrics: Dict,
    severity: str = "medium"
):
    """
    장애 해결 후 이력 저장
    
    Args:
        alert_name: 알람명
        root_cause: 근본 원인
        resolution: 해결 방법
        resolution_time_minutes: 해결 소요 시간
        metrics: 메트릭 스냅샷
        severity: 심각도
    """
    memory = IncidentMemory()
    
    incident_data = {
        'alert_name': alert_name,
        'root_cause': root_cause,
        'resolution': resolution,
        'resolution_time': resolution_time_minutes,
        'metrics': metrics,
        'severity': severity,
        'tags': [alert_name, severity]
    }
    
    incident_id = memory.save_incident(incident_data)
    print(f"✅ 장애 해결 이력 저장 완료: {incident_id}")
    return incident_id


# ============================================================
# Lambda Handler (기존 graph_agent 대체)
# ============================================================
def lambda_handler(event, context):
    """
    SNS 알람 → Bedrock Agent (메모리 활성화) → Slack
    """
    try:
        # SNS 메시지 파싱
        sns_message = json.loads(event['Records'][0]['Sns']['Message'])
        alert_name = sns_message.get('AlarmName', 'Unknown')
        
        # Agent 호출 (과거 이력 자동 참조)
        result = invoke_agent_with_memory(
            alert_name=alert_name,
            question=f"{alert_name} 알람이 발생했습니다. 원인을 분석하고 대응 방법을 제시해주세요.",
            enable_memory=True
        )
        
        # Slack 전송
        slack_message = f"""
🚨 *{alert_name}* 알람 발생

📊 과거 이력: {result['similar_incidents_count']}건
{'✅ 유사 장애 이력 참조됨' if result['has_history'] else '⚠️ 신규 장애 패턴'}

🤖 AI 분석:
{result['response']}

세션 ID: `{result['session_id']}`
"""
        
        # Slack 전송 로직...
        
        return {
            'statusCode': 200,
            'body': json.dumps({'message': '분석 완료', 'session_id': result['session_id']})
        }
        
    except Exception as e:
        print(f"❌ 오류: {e}")
        return {'statusCode': 500, 'body': str(e)}


# ============================================================
# CLI 테스트
# ============================================================
if __name__ == "__main__":
    # 테스트: 과거 이력 저장
    memory = IncidentMemory()
    
    # 예시 장애 저장
    memory.save_incident({
        'alert_name': 'HighJvmMemory',
        'root_cause': 'Memory leak in user session cache',
        'resolution': 'Restarted application and fixed cache eviction policy',
        'resolution_time': 45,
        'metrics': {'jvm_memory_used': 0.95, 'heap_size': '4GB'},
        'severity': 'high'
    })
    
    # 유사 장애 검색
    similar = memory.search_similar_incidents('HighJvmMemory')
    print(f"유사 장애 {len(similar)}건 발견")
    
    # 통계 조회
    stats = memory.get_incident_stats('HighJvmMemory')
    print(f"통계: {stats}")
