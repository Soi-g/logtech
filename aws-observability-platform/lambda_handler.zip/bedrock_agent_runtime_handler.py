"""
Bedrock Agent Runtime Handler with Strands Agents
SNS 알람 → Bedrock Agent (Strands Agents 사용) → Slack

장기 메모리: OpenSearch Serverless (벡터 검색)
"""

import os
import json
import boto3
import urllib.request
import urllib.parse
from datetime import datetime

# Strands Agents 임포트
from agents_aws import metrics_agent, logs_agent, traces_agent

# ============================================================
# 클라이언트 초기화
# ============================================================
bedrock_agent_runtime = boto3.client('bedrock-agent-runtime', region_name='ap-northeast-2')
bedrock_runtime = boto3.client('bedrock-runtime', region_name='ap-northeast-2')

AGENT_ID = os.environ.get('BEDROCK_AGENT_ID')
AGENT_ALIAS_ID = os.environ.get('BEDROCK_AGENT_ALIAS_ID')
AOSS_ENDPOINT = os.environ.get('AOSS_INCIDENT_MEMORY_ENDPOINT', '').replace('https://', '')
SLACK_BOT_TOKEN = os.environ.get('SLACK_BOT_TOKEN')
SLACK_CHANNEL = os.environ.get('SLACK_CHANNEL')
AWS_REGION = 'ap-northeast-2'


# ============================================================
# 장기 메모리 (OpenSearch Serverless)
# ============================================================
class IncidentMemory:
    """과거 장애 이력 관리 (AOSS 벡터 검색)"""
    
    def __init__(self):
        self.endpoint = AOSS_ENDPOINT
        self.index_name = "incident-memory-index"
    
    def _aoss_request(self, method: str, path: str, body: dict = None, max_retries: int = 3) -> dict:
        """AOSS API 요청 (SigV4 서명 + 재시도)"""
        import time
        
        for attempt in range(max_retries):
            try:
                session = boto3.Session()
                credentials = session.get_credentials().get_frozen_credentials()
                
                from botocore.auth import SigV4Auth
                from botocore.awsrequest import AWSRequest
                
                url = f"https://{self.endpoint}{path}"
                payload = json.dumps(body).encode('utf-8') if body else None
                
                request = AWSRequest(
                    method=method,
                    url=url,
                    data=payload,
                    headers={'Content-Type': 'application/json'} if body else {}
                )
                
                SigV4Auth(credentials, 'aoss', AWS_REGION).add_auth(request)
                
                req = urllib.request.Request(
                    url,
                    data=payload,
                    headers=dict(request.headers),
                    method=method
                )
                
                with urllib.request.urlopen(req, timeout=10) as response:
                    return json.loads(response.read())
            
            except urllib.error.HTTPError as e:
                if e.code == 403 and attempt < max_retries - 1:
                    # 403 Forbidden - AOSS 정책 전파 대기
                    wait_time = 2 ** attempt  # 지수 백오프: 1초, 2초, 4초
                    print(f"⚠️ AOSS 403 오류 (시도 {attempt + 1}/{max_retries}), {wait_time}초 대기 중...")
                    time.sleep(wait_time)
                    continue
                else:
                    raise
            
            except Exception as e:
                if attempt < max_retries - 1:
                    wait_time = 2 ** attempt
                    print(f"⚠️ AOSS 요청 실패 (시도 {attempt + 1}/{max_retries}): {e}, {wait_time}초 대기 중...")
                    time.sleep(wait_time)
                    continue
                else:
                    raise
        
        raise Exception(f"AOSS 요청 실패: {max_retries}회 재시도 후 실패")
    
    def search_similar_incidents(self, alert_name: str, error_message: str = "", limit: int = 3) -> list:
        """
        유사 장애 검색 (벡터 + 키워드)
        
        Args:
            alert_name: 알람명
            error_message: 에러 메시지 (벡터 검색용)
            limit: 결과 개수
        """
        try:
            # 벡터 임베딩 생성 (에러 메시지)
            if error_message:
                embedding = self._get_embedding(error_message)
            else:
                embedding = None
            
            # 검색 쿼리 구성
            query = {
                "size": limit,
                "query": {
                    "bool": {
                        "must": [
                            {"term": {"alert_name": alert_name}}
                        ]
                    }
                },
                "sort": [
                    {"timestamp": {"order": "desc"}}
                ]
            }
            
            # 벡터 검색 추가 (유사 에러 패턴)
            if embedding:
                query["query"]["bool"]["should"] = [
                    {
                        "knn": {
                            "log_pattern_vector": {
                                "vector": embedding,
                                "k": limit
                            }
                        }
                    }
                ]
            
            result = self._aoss_request('POST', f'/{self.index_name}/_search', query)
            
            incidents = []
            for hit in result.get('hits', {}).get('hits', []):
                source = hit['_source']
                incidents.append({
                    'incident_id': source.get('incident_id'),
                    'timestamp': source.get('timestamp'),
                    'root_cause': source.get('root_cause'),
                    'resolution': source.get('resolution'),
                    'resolution_time_minutes': source.get('resolution_time_minutes', 0),
                    'similarity_score': hit.get('_score', 0)
                })
            
            return incidents
        
        except Exception as e:
            print(f"⚠️ 유사 장애 검색 실패: {e}")
            return []
    
    def get_stats(self, alert_name: str) -> dict:
        """알람 통계 (resolved 상태만 집계)"""
        try:
            # 집계 쿼리
            query = {
                "size": 0,
                "query": {
                    "bool": {
                        "must": [
                            {"term": {"alert_name": alert_name}},
                            {"term": {"status": "resolved"}}  # 해결된 장애만
                        ]
                    }
                },
                "aggs": {
                    "total_count": {"value_count": {"field": "incident_id"}},
                    "avg_resolution_time": {"avg": {"field": "resolution_time_minutes"}},
                    "top_root_causes": {
                        "terms": {"field": "root_cause.keyword", "size": 1}
                    }
                }
            }
            
            result = self._aoss_request('POST', f'/{self.index_name}/_search', query)
            
            aggs = result.get('aggregations', {})
            count = aggs.get('total_count', {}).get('value', 0)
            
            if count == 0:
                return {'count': 0, 'is_new': True}
            
            top_causes = aggs.get('top_root_causes', {}).get('buckets', [])
            most_common = top_causes[0]['key'] if top_causes else "Unknown"
            
            return {
                'count': int(count),
                'is_new': False,
                'avg_resolution_time': aggs.get('avg_resolution_time', {}).get('value', 0),
                'most_common_cause': most_common
            }
        
        except Exception as e:
            print(f"⚠️ 통계 조회 실패: {e}")
            return {'count': 0, 'is_new': True}
    
    def save_incident(self, incident_data: dict):
        """장애 이력 저장"""
        try:
            incident_id = f"{incident_data['alert_name']}_{datetime.utcnow().isoformat()}"
            
            # 에러 메시지 벡터 임베딩
            error_messages = incident_data.get('error_messages', [])
            if error_messages:
                embedding = self._get_embedding(' '.join(error_messages))
            else:
                embedding = [0.0] * 1024  # 빈 벡터
            
            doc = {
                'incident_id': incident_id,
                'alert_name': incident_data['alert_name'],
                'timestamp': incident_data.get('state_change_time', datetime.utcnow().isoformat()),
                'severity': incident_data.get('severity', 'medium'),
                'root_cause': incident_data.get('root_cause', ''),
                'resolution': incident_data.get('resolution', ''),
                'resolution_time_minutes': incident_data.get('resolution_time', 0),
                'metrics': incident_data.get('metrics', {}),
                'log_pattern_vector': embedding,
                'error_messages': error_messages,
                'tags': [incident_data['alert_name'], incident_data.get('severity', 'medium')],
                'status': incident_data.get('status', 'ongoing')  # ongoing or resolved
            }
            
            self._aoss_request('POST', f'/{self.index_name}/_doc', doc)
            print(f"✅ 장애 이력 저장: {incident_id} (status: {doc['status']})")
        
        except Exception as e:
            print(f"⚠️ 장애 이력 저장 실패: {e}")
    
    def get_recent_ongoing_incident(self, alert_name: str) -> dict:
        """가장 최근 ongoing 상태 장애 조회"""
        try:
            query = {
                "size": 1,
                "query": {
                    "bool": {
                        "must": [
                            {"term": {"alert_name": alert_name}},
                            {"term": {"status": "ongoing"}}
                        ]
                    }
                },
                "sort": [{"timestamp": {"order": "desc"}}]
            }
            
            result = self._aoss_request('POST', f'/{self.index_name}/_search', query)
            hits = result.get('hits', {}).get('hits', [])
            
            if hits:
                return hits[0]['_source']
            return None
        
        except Exception as e:
            print(f"⚠️ ongoing 장애 조회 실패: {e}")
            return None
    
    def update_incident_resolution(self, incident_id: str, resolution: str, resolution_time_minutes: float):
        """장애 해결 정보 업데이트"""
        try:
            # incident_id로 문서 검색
            query = {
                "query": {
                    "term": {"incident_id.keyword": incident_id}
                }
            }
            
            result = self._aoss_request('POST', f'/{self.index_name}/_search', query)
            hits = result.get('hits', {}).get('hits', [])
            
            if not hits:
                print(f"⚠️ incident_id {incident_id}를 찾을 수 없음")
                return
            
            doc_id = hits[0]['_id']
            
            # 부분 업데이트
            update_doc = {
                "doc": {
                    "resolution": resolution,
                    "resolution_time_minutes": resolution_time_minutes,
                    "status": "resolved",
                    "resolved_at": datetime.utcnow().isoformat()
                }
            }
            
            self._aoss_request('POST', f'/{self.index_name}/_update/{doc_id}', update_doc)
            print(f"✅ 장애 해결 업데이트: {incident_id} ({resolution_time_minutes:.1f}분)")
        
        except Exception as e:
            print(f"⚠️ 장애 해결 업데이트 실패: {e}")
    
    def _get_embedding(self, text: str) -> list:
        """텍스트 임베딩 생성 (Bedrock Titan Embeddings)"""
        try:
            response = bedrock_runtime.invoke_model(
                modelId='amazon.titan-embed-text-v2:0',
                body=json.dumps({"inputText": text})
            )
            
            result = json.loads(response['body'].read())
            return result['embedding']
        
        except Exception as e:
            print(f"⚠️ 임베딩 생성 실패: {e}")
            return [0.0] * 1024


# ============================================================
# Strands Agents로 데이터 수집
# ============================================================
def collect_observability_data(question: str) -> dict:
    """
    Strands Agents를 사용하여 메트릭/로그/트레이스 수집
    """
    print(f"📊 Strands Agents로 데이터 수집 중...")
    
    results = {}
    
    try:
        # 메트릭 수집
        print(f"  - Metrics Agent 실행")
        metrics_result = metrics_agent(question)
        results['metrics'] = str(metrics_result)
    except Exception as e:
        print(f"  ⚠️ Metrics 수집 실패: {e}")
        results['metrics'] = f"수집 실패: {e}"
    
    try:
        # 로그 수집
        print(f"  - Logs Agent 실행")
        logs_result = logs_agent(question)
        results['logs'] = str(logs_result)
    except Exception as e:
        print(f"  ⚠️ Logs 수집 실패: {e}")
        results['logs'] = f"수집 실패: {e}"
    
    try:
        # 트레이스 수집
        print(f"  - Traces Agent 실행")
        traces_result = traces_agent(question)
        results['traces'] = str(traces_result)
    except Exception as e:
        print(f"  ⚠️ Traces 수집 실패: {e}")
        results['traces'] = f"수집 실패: {e}"
    
    print(f"✅ 데이터 수집 완료")
    return results


# ============================================================
# Bedrock Agent 호출
# ============================================================
def invoke_agent(alert_name: str, alert_description: str, severity: str = "medium") -> dict:
    """
    Bedrock Agent Runtime 호출
    
    Args:
        alert_name: 알람명
        alert_description: 알람 설명
        severity: 심각도
    
    Returns:
        Agent 응답 결과
    """
    
    # 1. 과거 이력 조회
    memory = IncidentMemory()
    stats = memory.get_stats(alert_name)
    similar = memory.search_similar_incidents(alert_name, limit=3)
    
    # 2. 컨텍스트 구성
    context = f"""
🚨 알람 발생
알람명: {alert_name}
심각도: {severity}
설명: {alert_description}

📊 과거 장애 이력:
"""
    
    if stats['is_new']:
        context += "⚠️ 신규 장애 패턴 (과거 이력 없음)\n"
    else:
        context += f"""
✅ 과거 {stats['count']}회 발생
📈 평균 해결 시간: {stats['avg_resolution_time']:.1f}분
🔍 가장 흔한 원인: {stats['most_common_cause']}

최근 3건:
"""
        for idx, incident in enumerate(similar[:3], 1):
            context += f"""
{idx}. {incident['timestamp']}
   원인: {incident.get('root_cause', 'Unknown')}
   해결: {incident.get('resolution', 'Unknown')}
   소요: {incident.get('resolution_time_minutes', 0)}분
"""
    
    context += """

📋 분석 요청:
1. 현재 메트릭, 로그, 트레이스를 조회하여 근본 원인 파악
2. 과거 이력을 참조하여 빠른 해결 방법 제시
3. 즉시 조치 및 후속 조치 권장
4. 관련 런북 참조

반드시 JSON 형식으로 응답하세요:
{
  "incident_summary": "한 문장 요약",
  "is_recurring": true/false,
  "past_occurrences": 숫자,
  "likely_root_causes": ["원인1", "원인2"],
  "severity": "심각도",
  "impact": "영향 범위",
  "immediate_actions": ["즉시 조치1", "즉시 조치2"],
  "follow_up_actions": ["후속 조치1"],
  "evidence_summary": ["근거1", "근거2"],
  "runbook_references": [{"source": "파일명", "section": "섹션", "relevance": "관련성"}]
}
"""
    
    # 3. 세션 ID 생성
    session_id = f"incident-{alert_name}-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}"
    
    print(f"🤖 Bedrock Agent 호출 시작")
    print(f"   Agent ID: {AGENT_ID}")
    print(f"   Session ID: {session_id}")
    print(f"   과거 이력: {stats['count']}건")
    
    try:
        # 4. Agent 호출
        response = bedrock_agent_runtime.invoke_agent(
            agentId=AGENT_ID,
            agentAliasId=AGENT_ALIAS_ID,
            sessionId=session_id,
            enableTrace=True,
            inputText=context
        )
        
        # 5. 응답 스트림 처리
        result_text = ""
        trace_data = []
        
        for event in response['completion']:
            if 'chunk' in event:
                chunk = event['chunk']
                if 'bytes' in chunk:
                    result_text += chunk['bytes'].decode('utf-8')
            
            if 'trace' in event:
                trace_data.append(event['trace'])
        
        print(f"✅ Agent 응답 완료 ({len(result_text)} 글자)")
        
        # 6. JSON 파싱 (개선된 로직)
        try:
            # 1단계: 마크다운 코드 블록 제거
            cleaned_text = result_text.strip()
            
            if '```json' in cleaned_text:
                cleaned_text = cleaned_text.split('```json')[1].split('```')[0].strip()
            elif '```' in cleaned_text:
                cleaned_text = cleaned_text.split('```')[1].split('```')[0].strip()
            
            # 2단계: JSON 객체 추출 (중괄호 기준)
            if '{' in cleaned_text and '}' in cleaned_text:
                start_idx = cleaned_text.find('{')
                end_idx = cleaned_text.rfind('}') + 1
                cleaned_text = cleaned_text[start_idx:end_idx]
            
            # 3단계: JSON 파싱
            report = json.loads(cleaned_text)
            print(f"✅ JSON 파싱 성공")
            
        except json.JSONDecodeError as e:
            print(f"⚠️ JSON 파싱 실패: {e}")
            print(f"   원본 텍스트 (처음 500자): {result_text[:500]}")
            
            # Fallback: 텍스트 응답을 구조화
            report = {
                "incident_summary": f"{alert_name} 알람 발생 - AI 분석 완료",
                "is_recurring": not stats['is_new'],
                "past_occurrences": stats['count'],
                "likely_root_causes": [stats.get('most_common_cause', '분석 필요')],
                "severity": severity,
                "impact": "영향 범위 파악 중",
                "immediate_actions": ["시스템 로그 확인", "담당자 호출"],
                "follow_up_actions": ["근본 원인 분석"],
                "evidence_summary": [f"AI 응답: {result_text[:200]}..."],
                "runbook_references": [],
                "raw_response": result_text  # 원본 응답 포함
            }
        
        return {
            'session_id': session_id,
            'report': report,
            'stats': stats,
            'trace': trace_data[:5] if trace_data else []  # 처음 5개만
        }
        
    except Exception as e:
        print(f"❌ Agent 호출 실패: {e}")
        raise


# ============================================================
# Slack 전송
# ============================================================
def send_to_slack(alert_name: str, result: dict):
    """Slack으로 분석 결과 전송"""
    
    report = result['report']
    stats = result['stats']
    session_id = result['session_id']
    
    # 재발 여부 표시
    if stats['is_new']:
        history_badge = "⚠️ 신규 장애 패턴"
    else:
        history_badge = f"🔄 재발 ({stats['count']}회 발생, 평균 {stats['avg_resolution_time']:.0f}분 소요)"
    
    # Slack 메시지 구성
    message = {
        "channel": SLACK_CHANNEL,
        "blocks": [
            {
                "type": "header",
                "text": {
                    "type": "plain_text",
                    "text": f"🚨 {alert_name}"
                }
            },
            {
                "type": "section",
                "fields": [
                    {"type": "mrkdwn", "text": f"*심각도:* {report.get('severity', 'medium')}"},
                    {"type": "mrkdwn", "text": f"*과거 이력:* {history_badge}"}
                ]
            },
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"*📝 요약*\n{report.get('incident_summary', 'N/A')}"
                }
            },
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"*🔍 가능한 원인*\n" + "\n".join([f"• {cause}" for cause in report.get('likely_root_causes', [])])
                }
            },
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"*⚡ 즉시 조치*\n" + "\n".join([f"{i+1}. {action}" for i, action in enumerate(report.get('immediate_actions', []))])
                }
            }
        ]
    }
    
    # 런북 참조 추가
    runbooks = report.get('runbook_references', [])
    if runbooks:
        runbook_text = "*📖 관련 런북*\n"
        for rb in runbooks[:3]:
            runbook_text += f"• [{rb.get('source', 'Unknown')}] {rb.get('section', '')}\n"
        
        message['blocks'].append({
            "type": "section",
            "text": {"type": "mrkdwn", "text": runbook_text}
        })
    
    # 세션 정보
    message['blocks'].append({
        "type": "context",
        "elements": [
            {"type": "mrkdwn", "text": f"Session: `{session_id}`"}
        ]
    })
    
    _send_slack_message(message)


def send_resolution_to_slack(alert_name: str, resolution_minutes: float):
    """Slack으로 장애 해결 알림 전송"""
    
    message = {
        "channel": SLACK_CHANNEL,
        "blocks": [
            {
                "type": "header",
                "text": {
                    "type": "plain_text",
                    "text": f"✅ {alert_name} 해결"
                }
            },
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"*소요 시간:* {resolution_minutes:.1f}분\n*상태:* 정상 복구"
                }
            },
            {
                "type": "context",
                "elements": [
                    {"type": "mrkdwn", "text": "장기 메모리에 해결 정보가 저장되었습니다."}
                ]
            }
        ]
    }
    
    _send_slack_message(message)


def _send_slack_message(message: dict):
    """Slack API 호출 헬퍼"""
    import urllib.request
    import urllib.parse
    
    headers = {
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {SLACK_BOT_TOKEN}'
    }
    
    data = json.dumps(message).encode('utf-8')
    req = urllib.request.Request(
        'https://slack.com/api/chat.postMessage',
        data=data,
        headers=headers
    )
    
    try:
        with urllib.request.urlopen(req) as response:
            result = json.loads(response.read())
            if result.get('ok'):
                print(f"✅ Slack 전송 완료")
            else:
                print(f"⚠️ Slack 전송 실패: {result.get('error')}")
    except Exception as e:
        print(f"❌ Slack 전송 오류: {e}")


# ============================================================
# Lambda Handler
# ============================================================
def lambda_handler(event, context):
    """
    SNS 알람 → Bedrock Agent → Slack
    
    메모리 전환 전략:
    1. ALARM 상태: 초기 분석 + AOSS 저장 (status: ongoing)
    2. OK 상태: 해결 정보 업데이트 (status: resolved)
    """
    
    print(f"📥 이벤트 수신: {json.dumps(event)}")
    
    try:
        # SNS 메시지 파싱
        sns_message = json.loads(event['Records'][0]['Sns']['Message'])
        
        alert_name = sns_message.get('AlarmName', 'Unknown')
        alert_description = sns_message.get('AlarmDescription', '')
        new_state = sns_message.get('NewStateValue', 'ALARM')
        state_change_time = sns_message.get('StateChangeTime', datetime.utcnow().isoformat())
        
        print(f"🚨 알람: {alert_name} ({new_state})")
        
        memory = IncidentMemory()
        
        # ============================================================
        # ALARM 상태: 분석 + 장기 메모리 저장
        # ============================================================
        if new_state == 'ALARM':
            # Bedrock Agent 호출
            result = invoke_agent(
                alert_name=alert_name,
                alert_description=alert_description,
                severity='high'
            )
            
            # Slack 전송
            send_to_slack(alert_name, result)
            
            # 장기 메모리 저장 (초기 분석)
            report = result['report']
            incident_data = {
                'alert_name': alert_name,
                'severity': report.get('severity', 'high'),
                'root_cause': ', '.join(report.get('likely_root_causes', [])),
                'resolution': 'ongoing',  # 아직 미해결
                'resolution_time': 0,
                'metrics': {
                    'session_id': result['session_id'],
                    'is_recurring': not result['stats']['is_new'],
                    'past_occurrences': result['stats']['count']
                },
                'error_messages': report.get('evidence_summary', []),
                'state_change_time': state_change_time,
                'status': 'ongoing'
            }
            
            memory.save_incident(incident_data)
            print(f"✅ 장기 메모리 저장 완료 (status: ongoing)")
            
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'message': '분석 완료 및 메모리 저장',
                    'session_id': result['session_id'],
                    'is_recurring': not result['stats']['is_new']
                })
            }
        
        # ============================================================
        # OK 상태: 해결 정보 업데이트
        # ============================================================
        elif new_state == 'OK':
            # 가장 최근 ongoing 장애 조회
            recent_incident = memory.get_recent_ongoing_incident(alert_name)
            
            if recent_incident:
                # 해결 시간 계산
                start_time = datetime.fromisoformat(recent_incident['timestamp'].replace('Z', '+00:00'))
                end_time = datetime.fromisoformat(state_change_time.replace('Z', '+00:00'))
                resolution_minutes = (end_time - start_time).total_seconds() / 60
                
                # 해결 정보 업데이트
                memory.update_incident_resolution(
                    incident_id=recent_incident['incident_id'],
                    resolution='자동 복구',  # 실제로는 Bedrock Agent에게 물어볼 수도 있음
                    resolution_time_minutes=resolution_minutes
                )
                
                print(f"✅ 장애 해결 업데이트: {resolution_minutes:.1f}분 소요")
                
                # Slack 알림 (선택)
                send_resolution_to_slack(alert_name, resolution_minutes)
            else:
                print(f"⚠️ 해결할 ongoing 장애를 찾을 수 없음")
            
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'message': '장애 해결 업데이트',
                    'resolution_time_minutes': resolution_minutes if recent_incident else 0
                })
            }
        
        # ============================================================
        # 기타 상태 (INSUFFICIENT_DATA 등)
        # ============================================================
        else:
            print(f"⏭️ {new_state} 상태, 스킵")
            return {'statusCode': 200, 'body': f'Skipped ({new_state})'}
        
    except Exception as e:
        print(f"❌ 오류: {e}")
        import traceback
        traceback.print_exc()
        
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
